package utilities

import "os/exec"

func TellCommandNotToSpawnShell(_ *exec.Cmd) {
}
