package browser

func Find(process string) ([]byte, error) {
	return nil, nil
}

func Kill(process string) ([]byte, error) {
	return nil, nil
}

func Start(command []byte, url string) ([]byte, error) {
	return nil, nil
}
